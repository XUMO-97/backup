#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from ontology.ont_sdk import OntologySdk


class Nep4(object):
    def __init__(self, sdk: OntologySdk):
        # TODO：self.nep6_abi
        i = 0