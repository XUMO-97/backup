#!/usr/bin/env python3
# -*- coding: utf-8 -*-


class AccountInfo:
    def __init__(self):
        self.address_base58 = ""
        self.public_key = ""
        self.encrypted_pri_key = ""
        self.address_u160 = ""
        self.private_key = ""
        self.pri_key_wif = ""
